#define X(a,b, \
	c,d) \
	foo

X(1,2,3,4)
